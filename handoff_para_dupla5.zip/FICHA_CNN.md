# Ficha da CNN - Dupla 6 (Íris, base principal IIT Delhi)
- Arquitetura: mobilenet_v3_small (família MobileNet)
- Origem dos pesos / pré-treino: torchvision, ImageNet
- Camadas congeladas / treinadas: PREENCHER (ver train.py; freeze_backbone em model.py)
- Função de perda: CosFace (s=30, m=0.30) sobre embeddings L2-normalizados (ver model.py)
- Dimensão do embedding: 128
- Nº de parâmetros: 1,289,376
- Matching: Similaridade de cosseno (embeddings L2-normalizados)
- Threshold: EER na validação do IITD, congelado antes do teste
- Rubber Sheet: True | Seeds: [42, 123, 2026] | Hardware: Intel64 Family 6 Model 58 Stepping 9, GenuineIntel
